-- This script is deprecated in favor of using the /seed-staff-auth page
-- Staff members must be created through Supabase Auth API first
-- Then linked to the staff table

-- To create staff with authentication:
-- 1. Navigate to /seed-staff-auth
-- 2. Click "Create Auth Accounts"
-- 3. This will create authentication accounts and staff records for:
--    - jmwangi (Director)
--    - james.director (Director)
--    - sarah.director (Director)
--    - john.manager (Manager)
--    - mary.manager (Manager)
--    - peter.supervisor (Supervisor)
--    - jane.supervisor (Supervisor)
--    - david.cashier (Cashier)
--    - lucy.cashier (Cashier)

-- All accounts will have the default password: flow360
